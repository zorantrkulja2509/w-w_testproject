﻿namespace TicketSales.Messages.Commands
{
    public class GetAllConcertsCommand
    {
    }
}
