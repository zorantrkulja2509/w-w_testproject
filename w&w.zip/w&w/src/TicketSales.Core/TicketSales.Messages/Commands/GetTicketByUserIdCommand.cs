﻿namespace TicketSales.Messages.Commands
{
    public class GetTicketByUserIdCommand
    {
        public int UserId { get; set; }
    }
}